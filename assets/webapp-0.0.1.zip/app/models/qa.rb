module Qa
  def self.table_name_prefix
    'qa_'
  end
end
