# Generated via
#  `rails generate hyrax:work Work`
require 'rails_helper'

RSpec.describe Work do
  it "has tests" do
    skip "Add your tests here"
  end
end
