# Generated via
#  `rails generate hyrax:work Work`
require 'rails_helper'

RSpec.describe Hyrax::WorkForm do
  it "has tests" do
    skip "Add your tests here"
  end
end
