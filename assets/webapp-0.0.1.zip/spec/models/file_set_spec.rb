require 'rails_helper'

RSpec.describe FileSet do
  it "has tests" do
    skip "Add your tests here"
  end
end
