require 'rails_helper'

RSpec.describe Collection do
  it "has tests" do
    skip "Add your tests here"
  end
end
