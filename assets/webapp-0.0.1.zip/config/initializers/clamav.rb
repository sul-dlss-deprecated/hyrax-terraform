ClamAV.instance.loaddb if defined? ClamAV
