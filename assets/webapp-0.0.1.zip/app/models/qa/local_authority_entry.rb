class Qa::LocalAuthorityEntry < ApplicationRecord
  belongs_to :local_authority
end
