//= require openseadragon/openseadragon
//= require openseadragon/rails