class Qa::LocalAuthority < ApplicationRecord
end
